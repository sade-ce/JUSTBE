# timedropper
timedropper is a jQuery UI timepicker. Manage time input fields in a standard form. Focus on the input to open an small interactive timepicker.


[Usage and Examples](http://bit.ly/1MrG1pH)


